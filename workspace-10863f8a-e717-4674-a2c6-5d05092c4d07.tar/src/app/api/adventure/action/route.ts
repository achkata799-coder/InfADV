import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

const SYSTEM_PROMPT = `You are an immersive, infinite AI adventure game master. Your role is to create compelling, dynamic narratives that respond meaningfully to player choices.

CRITICAL INSTRUCTIONS:

1. ALWAYS respond with a JSON object containing these fields:
   {
     "narrative": "The story text in second person perspective (2-4 paragraphs)",
     "gameState": { health: number, gold: number, location: string, timeOfDay: string },
     "inventory": [{ "itemName": string, "description": string, "quantity": number, "rarity": "common|rare|epic|legendary", "itemType": string }],
     "quests": [{ "title": string, "description": string, "status": "active|completed|failed", "priority": "low|normal|high" }],
     "relationships": [{ "npcName": string, "npcRole": string, "affinity": number (0-100), "status": "hostile|neutral|friendly|ally", "interactionCount": number }],
     "reputation": [{ "factionName": string, "factionType": string, "reputation": number, "description": string }],
     "imagePrompt": "A detailed visual prompt for scene generation (max 200 words)",
     "characters": [{ "name": string, "role": string, "description": string, "personality": {}, "goals": {} }]
   }

2. TEXT FORMATTING RULES (CRITICAL):
   The "narrative" field MUST use markdown formatting as follows:
   
   a) All spoken dialogue must appear within quotation marks AND use bold markdown:
      Example: "**"Hello, traveler. Welcome to my shop."**"
   
   b) Names of characters, NPCs, and locations must be rendered in bold WITHOUT quotation marks:
      Examples: "**Elara**", **Blackwood Forest**, **The Ancient Temple**, **Guard Captain Marcus**
   
   c) Environmental descriptions, general narrative prose, and standard character actions must appear in normal (non-bold, non-italic) text
   
   d) Key or noteworthy details—such as important objects, hidden clues, significant emotional cues, or critical environmental features—must be presented in italicized text:
      Examples: *ancient runes glow faintly*, *a sense of unease washes over you*, *the key glistens in the torchlight*
   
   e) Use clear paragraph breaks (double line breaks) to separate major sections of the narrative
   
   f) DO NOT overuse formatting. Only apply formatting when it enhances readability and highlights important information.
   
   Examples of properly formatted text:
   "You step into **The Golden Griffin Inn**, the warmth immediately embracing you. **Bartender Elara** waves from behind the counter. 
   
   **"Good evening! What brings you here on such a stormy night?"** she asks, her eyes twinkling with *genuine concern*.
   
   You notice *an elderly man in the corner* watching you intently, his *weathered face* marked by countless battles."

3. Game State Management:
   - Health: 0-100, affected by combat, hazards, healing
   - Gold: Currency for purchases, rewards
   - Location: Describe where player is
   - Time: day/night/evening/dawn

4. Inventory Rules:
   - Add items when player finds, purchases, or receives them
   - Remove items when used, sold, or lost
   - Quantity changes for consumables
   - Rarity: common (default), rare, epic, legendary

5. Quest Rules:
   - Create new quests when objectives arise
   - Mark as completed when player fulfills requirements
   - Failed when player makes critical mistakes
   - Priority affects urgency and rewards

6. Relationship Rules:
   - Affinity: 0-100 scale
   - Status: hostile (<30), neutral (30-70), friendly (70-89), ally (90+)
   - InteractionCount: increment with each NPC encounter
   - Affinity changes based on player choices

7. Reputation Rules:
   - Faction reputation: can be negative or positive
   - Affects NPC reactions, prices, quest availability
   - Influences world events

8. Narrative Style:
   - Write in second person ("You see...")
   - Be descriptive but concise
   - Create tension and stakes
   - Offer meaningful choices through narrative
   - Avoid predetermined paths
   - React organically to unexpected player actions
   - Maintain world consistency
   - Apply formatting rules consistently

9. Image Generation:
   - Create detailed, evocative prompts
   - Focus on atmosphere and mood
   - Include key visual elements
   - Max 200 words

10. World Building:
    - Generate unique NPCs with personalities and goals
    - Create diverse locations with unique features
    - Environmental changes (weather, time, seasons)
    - Dynamic events and world states

11. Emergent Gameplay:
    - Allow unexpected player choices
    - Create consequences for actions
    - Build on previous events
    - Adapt story based on game state

12. Action Types - Handle these differently:
    - "do" (custom): Player describes a physical/mental action - AI narrates the outcome and consequences
    - "say" (custom): Player character speaks dialogue - AI incorporates it and responds
    - "see" (custom): Player observes environment - AI describes what's seen/hidden
    - "story" (custom): Player adds narrative element - AI weaves it into the story
    - "wait" (special): Player waits - advance time, may trigger random events
    - "custom" (default): Any other free-form action - AI responds as a standard game turn

13. NPC Memory System:
    - Track what NPCs know about player and world
    - Remember significant interactions and events
    - NPCs should reference past interactions in responses
    - Update character knowledge field with new information learned
`

async function generateNarrative(
  playerAction: string,
  actionType: 'do' | 'say' | 'see' | 'story' | 'wait' | 'custom',
  history: Array<{ role: string; content: string }>,
  currentState: any,
  existingCharacters: any[]
) {
  const zai = await ZAI.create()

  let actionInstruction = ''
  switch (actionType) {
    case 'do':
      actionInstruction = 'The player is attempting a physical or mental action. Describe the outcome, consequences, and any changes to game state (health, inventory, etc.). Be realistic but keep the story engaging.'
      break
    case 'say':
      actionInstruction = 'The player character is speaking or communicating. Incorporate their words into the narrative. Consider their tone and intent. NPCs and other characters should respond naturally.'
      break
    case 'see':
      actionInstruction = 'The player is observing or inspecting something. Describe what they see, including details, hidden elements, or things they notice. This is a discovery action.'
      break
    case 'story':
      actionInstruction = 'The player is adding a story element, background, or narrative direction. Weave this into the existing story naturally. It should feel organic and add depth to the world.'
      break
    case 'wait':
      actionInstruction = 'The player is waiting and observing. Significantly advance the time of day if appropriate. This can trigger random events, NPC encounters, environmental changes, or progress. Introduce something new or develop the story while they wait.'
      break
    default:
      actionInstruction = 'The player is performing an action. Respond naturally, maintaining story continuity, consequences, and character consistency. Update all relevant game systems.'
  }

  const contextPrompt = `Current Game State:
- Health: ${currentState.health}/${currentState.maxHealth}
- Gold: ${currentState.gold}
- Level: ${currentState.level}
- Experience: ${currentState.experience}
- Location: ${currentState.location || 'Unknown'}
- Time of Day: ${currentState.timeOfDay}

Action Type: ${actionType}
Player Action: "${playerAction}"

History of recent events:
${history.slice(-6).map(h => `${h.role}: ${h.content}`).join('\n')}

Existing NPCs:
${existingCharacters.map(c => `- ${c.name} (${c.role}): ${c.description}\n  Memory: ${c.memory || 'No memory available'}`).join('\n')}

${actionInstruction}

Based on player's action and current game state, generate the next chapter of story. Consider how to action affects all game systems (health, inventory, quests, relationships, reputation). Create meaningful consequences and new opportunities. Keep the story open-ended but engaging.

IMPORTANT: If this involves NPC interactions, check if you should update NPC memory or knowledge. Update the "memory" and "knowledge" fields for relevant characters.

Your response MUST include the complete JSON object structure shown above.`

  const messages = [
    { role: 'assistant', content: SYSTEM_PROMPT },
    { role: 'user', content: contextPrompt }
  ]

  const completion = await zai.chat.completions.create({
    messages,
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    }
    throw new Error('No JSON found in response')
  } catch (error) {
    console.error('Failed to parse AI response:', error)
    return null
  }
}

export async function POST(req: NextRequest) {
  try {
    const { sessionId, action, actionType = 'custom' } = await req.json()

    if (!sessionId || !action) {
      return NextResponse.json(
        { success: false, error: 'Session ID and action are required' },
        { status: 400 }
      )
    }

    const session = await db.gameSession.findUnique({
      where: { id: sessionId },
      include: {
        playerState: true,
        inventory: true,
        quests: true,
        relationships: true,
        reputation: true,
        characters: true,
        dialogues: {
          orderBy: { turnNumber: 'asc' },
          take: 10
        },
        worldStates: true
      }
    })

    if (!session) {
      return NextResponse.json(
        { success: false, error: 'Session not found' },
        { status: 404 }
      )
    }

    const currentState = session.playerState
    const history = session.dialogues.map(d => ({ role: d.role, content: d.content }))
    const existingCharacters = session.characters

    const result = await generateNarrative(action, actionType, history, currentState, existingCharacters)

    if (!result) {
      return NextResponse.json(
        { success: false, error: 'Failed to generate narrative' },
        { status: 500 }
      )
    }

    const turnNumber = history.length + 1

    await db.$transaction([
      db.gameState.update({
        where: { sessionId },
        data: {
          health: result.gameState.health,
          gold: result.gameState.gold,
          level: result.gameState.level,
          experience: result.gameState.experience,
          location: result.gameState.location,
          timeOfDay: result.gameState.timeOfDay,
          currentScene: result.narrative,
          currentImagePrompt: result.imagePrompt,
          lastAction: action,
          updatedAt: new Date()
        }
      }),

      db.dialogueHistory.create({
        data: {
          sessionId,
          role: 'user',
          content: action,
          turnNumber,
          createdAt: new Date()
        }
      }),

      db.dialogueHistory.create({
        data: {
          sessionId,
          role: 'assistant',
          content: result.narrative,
          turnNumber: turnNumber + 1,
          imagePrompt: result.imagePrompt,
          gameState: JSON.stringify(result),
          createdAt: new Date()
        }
      }),

      db.inventory.deleteMany({ where: { sessionId } }),
      ...result.inventory.map((item: any) =>
        db.inventory.create({
          data: {
            sessionId,
            itemName: item.itemName,
            description: item.description,
            quantity: item.quantity,
            rarity: item.rarity,
            itemType: item.itemType
          }
        })
      ),

      db.quest.deleteMany({ where: { sessionId } }),
      ...result.quests.map((quest: any) =>
        db.quest.create({
          data: {
            sessionId,
            title: quest.title,
            description: quest.description,
            objectives: JSON.stringify(quest.objectives || []),
            status: quest.status,
            priority: quest.priority,
            completedAt: quest.status === 'completed' ? new Date() : null
          }
        })
      ),

      db.relationship.deleteMany({ where: { sessionId } }),
      ...result.relationships.map((rel: any) =>
        db.relationship.update({
          where: { 
            sessionId,
            npcName: rel.npcName
          },
          data: {
            affinity: rel.affinity,
            status: rel.status,
            interactionCount: rel.interactionCount,
            lastInteraction: new Date().toISOString(),
            updatedAt: new Date()
          }
        })
      ),

      db.reputation.deleteMany({ where: { sessionId } }),
      ...result.reputation.map((rep: any) =>
        db.reputation.update({
          where: {
            sessionId,
            factionName: rep.factionName
          },
          data: {
            reputation: rep.reputation,
            description: rep.description,
            updatedAt: new Date()
          }
        })
      ),

      db.character.deleteMany({ where: { sessionId } }),
      ...(result.characters || []).map((char: any) =>
        db.character.upsert({
          where: {
            sessionId,
            name: char.name
          },
          create: {
            sessionId,
            name: char.name,
            role: char.role,
            description: char.description,
            personality: JSON.stringify(char.personality || {}),
            goals: JSON.stringify(char.goals || {}),
            location: currentState.location,
            memory: JSON.stringify(char.memory || {}),
            knowledge: JSON.stringify(char.knowledge || {}),
            secretsKnown: JSON.stringify(char.secretsKnown || {}),
            recentInteractions: JSON.stringify(char.recentInteractions || []),
            firstMetAt: char.firstMetAt || new Date(),
            createdAt: new Date(),
            updatedAt: new Date()
          },
          update: {
            ...(char.id ? { id: char.id } : {}),
            memory: JSON.stringify(char.memory || {}),
            knowledge: JSON.stringify(char.knowledge || {}),
            secretsKnown: JSON.stringify(char.secretsKnown || {}),
            recentInteractions: JSON.stringify(char.recentInteractions || []),
            updatedAt: new Date()
          }
        })
      )
    ])

    const updatedSession = await db.gameSession.findUnique({
      where: { id: sessionId },
      include: {
        playerState: true,
        inventory: true,
        quests: true,
        relationships: true,
        reputation: true,
        characters: true,
        dialogues: {
          orderBy: { turnNumber: 'desc' },
          take: 20
        }
      }
    })

    return NextResponse.json({
      success: true,
      response: result.narrative,
      gameState: updatedSession?.playerState,
      inventory: updatedSession?.inventory,
      quests: updatedSession?.quests,
      relationships: updatedSession?.relationships,
      reputation: updatedSession?.reputation,
      imagePrompt: result.imagePrompt
    })
  } catch (error) {
    console.error('Adventure action error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
