import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

interface GameSettings {
  setting?: string
  genre?: string
  plotEssentials?: string
  mediaType?: string
}

async function generateIntro(settings: GameSettings = {}) {
  const zai = await ZAI.create()

  const contextPrompt = settings.setting || settings.genre
    ? `Game Settings:
- Setting: ${settings.setting || 'Not specified'}
- Genre/Theme: ${settings.genre || 'Not specified'}
- Plot Essentials: ${settings.plotEssentials || 'Not specified'}
- Media Type: ${settings.mediaType || 'Traditional adventure game'}

Use these settings to craft a unique world, lore, and opening scene that reflects the player's preferences.`
    : ''

  const introPrompt = `Create an immersive opening scene for an infinite AI adventure game. ${contextPrompt}

You must respond with a JSON object containing:
{
  "narrative": "An engaging 2-3 paragraph opening scene written in second person that establishes a mysterious, compelling world and presents immediate opportunities for adventure",
  "gameState": { "health": 100, "gold": 50, "location": "descriptive location name", "timeOfDay": "day" },
  "inventory": [{ "itemName": "item name", "description": "brief description", "quantity": 1, "rarity": "common", "itemType": "type" }],
  "quests": [{ "title": "quest name", "description": "what the player must do", "status": "active", "priority": "normal" }],
  "relationships": [],
  "reputation": [],
  "imagePrompt": "A detailed visual description for generating an atmospheric scene image (max 150 words)",
  "characters": []
}

Create a unique, atmospheric opening that hooks the player immediately. Establish an interesting location, hint at a larger world, and provide at least one immediate choice or mystery.

The AI should also initialize basic world knowledge and some starting NPCs with their personalities and initial states.

IMPORTANT: Include the Character model's memory system fields (memory, knowledge, secretsKnown, recentInteractions) for any NPCs you create. This will enable the NPC memory system.

The "characters" array should follow this structure for each NPC:
{
  "name": "NPC name",
  "role": "NPC role (e.g., Shopkeeper, Guard, Village Elder)",
  "description": "Brief description",
  "personality": { "traits": ["trait1", "trait2"], "values": { "value1": "quality1", "value2": "quality2" } },
  "goals": { "primary": "goal description", "secondary": ["other goal"] },
  "location": "starting location",
  "memory": "{}",
  "knowledge": "{}",
  "secretsKnown": "[]",
  "recentInteractions": "[]"
}`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'assistant',
        content: 'You are a creative game master who creates immersive adventure game openings. Always respond with valid JSON containing narrative, gameState, inventory, quests, relationships, reputation, imagePrompt, and characters fields. Include NPC memory system fields (memory, knowledge, secretsKnown, recentInteractions) in characters array.'
      },
      {
        role: 'user',
        content: introPrompt
      }
    ],
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    }
    throw new Error('No JSON found in response')
  } catch (error) {
    console.error('Failed to parse intro response:', error)
    return null
  }
}

export async function POST(req: NextRequest) {
  try {
    const settings = await req.json() as GameSettings
    const intro = await generateIntro(settings)

    if (!intro) {
      return NextResponse.json(
        { success: false, error: 'Failed to generate game introduction' },
        { status: 500 }
      )
    }

    const session = await db.gameSession.create({
      data: {
        playerState: {
          create: {
            health: intro.gameState.health,
            maxHealth: 100,
            gold: intro.gameState.gold,
            level: 1,
            experience: 0,
            location: intro.gameState.location,
            timeOfDay: intro.gameState.timeOfDay,
            currentScene: intro.narrative,
            currentImagePrompt: intro.imagePrompt
          }
        }
      },
      include: {
        playerState: true
      }
    })

    await db.dialogueHistory.create({
      data: {
        sessionId: session.id,
        role: 'system',
        content: 'Game initialized',
        turnNumber: 0
      }
    })

    await db.dialogueHistory.create({
      data: {
        sessionId: session.id,
        role: 'assistant',
        content: intro.narrative,
        turnNumber: 1,
        imagePrompt: intro.imagePrompt,
        gameState: JSON.stringify(intro),
        createdAt: new Date()
      }
    })

    for (const item of intro.inventory) {
      await db.inventory.create({
        data: {
          sessionId: session.id,
          itemName: item.itemName,
          description: item.description,
          quantity: item.quantity,
          rarity: item.rarity,
          itemType: item.itemType
        }
      })
    }

    for (const quest of intro.quests) {
      await db.quest.create({
        data: {
          sessionId: session.id,
          title: quest.title,
          description: quest.description,
          objectives: JSON.stringify(quest.objectives || []),
          status: quest.status,
          priority: quest.priority
        }
      })
    }

    if (intro.characters && intro.characters.length > 0) {
      for (const char of intro.characters) {
        await db.character.create({
          data: {
            sessionId: session.id,
            name: char.name,
            role: char.role,
            description: char.description,
            personality: JSON.stringify(char.personality || {}),
            goals: JSON.stringify(char.goals || {}),
            location: char.location,
            memory: JSON.stringify(char.memory || {}),
            knowledge: JSON.stringify(char.knowledge || {}),
            secretsKnown: JSON.stringify(char.secretsKnown || {}),
            recentInteractions: JSON.stringify(char.recentInteractions || []),
            firstMetAt: new Date(),
            createdAt: new Date(),
            updatedAt: new Date()
          }
        })
      }
    }

    const fullSession = await db.gameSession.findUnique({
      where: { id: session.id },
      include: {
        playerState: true,
        inventory: true,
        quests: true,
        relationships: true,
        reputation: true,
        characters: true,
        worldStates: true,
        dialogues: {
          orderBy: { turnNumber: 'desc' },
          take: 20
        }
      }
    })

    return NextResponse.json({
      success: true,
      sessionId: session.id,
      gameState: fullSession?.playerState,
      dialogues: fullSession?.dialogues.reverse(),
      inventory: fullSession?.inventory,
      quests: fullSession?.quests,
      relationships: fullSession?.relationships,
      reputation: fullSession?.reputation,
      characters: fullSession?.characters
    })
  } catch (error) {
    console.error('Init game error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
