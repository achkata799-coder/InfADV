import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

const SYSTEM_PROMPT = `You are an AI adventure game master specializing in NPC interaction trees. Your role is to generate contextually appropriate dialogue and action options for player-NPC interactions.

CRITICAL INSTRUCTIONS:

1. ALWAYS respond with a JSON object containing these fields:
   {
     "npcResponse": "Brief greeting or opening statement from the NPC (1-2 sentences)",
     "dialogueOptions": [
       {
         "id": "unique_id",
         "type": "greeting|question|action|trade|quest|compliment|threat|flirt|persuade|intimidate|custom",
         "text": "The dialogue text the player will say (in first person)",
         "description": "What this option accomplishes or its intent (brief)",
         "requirements": {
           "minAffinity": 0,
           "maxAffinity": 100,
           "requiredItems": [],
           "requiredQuests": [],
           "blockedIf": []
         }
       }
     ],
     "actionOptions": [
       {
         "id": "unique_id",
         "type": "attack|gift|steal|trade|companion|custom",
         "text": "The action description (in first person)",
         "description": "What this action does",
         "requirements": {
           "minAffinity": 0,
           "requiredItems": []
         }
       }
     ]
   }

2. Context Analysis:
   - Analyze NPC's personality traits and values
   - Consider current relationship status and affinity score
   - Review NPC's memory of past interactions with player
   - Check NPC's knowledge and secrets they hold
   - Consider world events and current location
   - Factor in player's inventory, quests, and reputation

3. Relationship-Based Options:
   - Hostile (<30 affinity): Limited options, mostly hostile or defensive
   - Neutral (30-70 affinity): Basic dialogue and standard interactions
   - Friendly (70-89 affinity): Expanded dialogue, quest offers, trade
   - Ally (90+ affinity): All options available, special offers, companionship

4. NPC Memory Integration:
   - Reference past interactions in NPC's opening response
   - Suggest dialogue options that reference shared history
   - Include options related to secrets the NPC knows
   - Consider promises or debts remembered from past encounters

5. Option Types:
   - Greeting: Basic greetings appropriate to relationship level
   - Question: Ask about topics, lore, quests, or the NPC's knowledge
   - Action: Physical actions (give item, attack, hug, etc.)
   - Trade: Offer items for trade or ask about shops
   - Quest: Discuss active quests or request new ones
   - Compliment: Praise NPC, boosts relationship
   - Threat: Intimidate NPC, lowers relationship, may reveal info
   - Flirt: Romantic dialogue, requires appropriate relationship
   - Persuade: Try to convince NPC of something
   - Intimidate: Use force or threats to get information

6. Dynamic Adaptation:
   - Include references to world events or current location context
   - Mention player's active quests when relevant
   - Reference items player has that NPC might want
   - Consider faction reputation with NPC's affiliations
   - Adapt based on time of day, weather, or environment

7. Requirements System:
   - Set appropriate affinity thresholds for different options
   - Specify required items for certain interactions
   - Block options based on past choices or NPC disposition
   - Consider quest prerequisites for certain dialogue paths

8. Generate 4-6 dialogue options and 2-3 action options based on context

Your response MUST include the complete JSON object structure shown above.`

async function generateNPCDialogueOptions(
  npcName: string,
  sessionId: string,
  npcData: any,
  playerData: any,
  recentHistory: Array<{ role: string; content: string }>
) {
  const zai = await ZAI.create()

  // Parse NPC memory and knowledge
  const memory = npcData.memory ? JSON.parse(npcData.memory) : {}
  const knowledge = npcData.knowledge ? JSON.parse(npcData.knowledge) : {}
  const secretsKnown = npcData.secretsKnown ? JSON.parse(npcData.secretsKnown) : []
  const recentInteractions = npcData.recentInteractions ? JSON.parse(npcData.recentInteractions) : []
  const personality = npcData.personality ? JSON.parse(npcData.personality) : {}

  const contextPrompt = `Generate NPC dialogue options for this interaction:

NPC Information:
- Name: ${npcName}
- Role: ${npcData.role || 'Unknown'}
- Description: ${npcData.description}
- Personality Traits: ${Object.values(personality).join(', ') || 'Not specified'}
- Goals: ${npcData.goals ? JSON.stringify(npcData.goals) : 'Not specified'}

NPC Memory & Knowledge:
- Memory of Past Events: ${Object.keys(memory).length > 0 ? JSON.stringify(memory) : 'No significant memories'}
- World Knowledge: ${Object.keys(knowledge).length > 0 ? JSON.stringify(knowledge) : 'Basic knowledge'}
- Secrets Known: ${secretsKnown.length > 0 ? secretsKnown.join(', ') : 'No significant secrets'}
- Recent Interactions: ${recentInteractions.length > 0 ? recentInteractions.slice(-3).join('; ') : 'No recent interactions'}

Player Information:
- Health: ${playerData.health}/${playerData.maxHealth}
- Gold: ${playerData.gold}
- Level: ${playerData.level}
- Location: ${playerData.location || 'Unknown'}
- Time: ${playerData.timeOfDay}

Player Inventory: ${playerData.inventory?.map((i: any) => i.itemName).join(', ') || 'None'}
Active Quests: ${playerData.quests?.map((q: any) => q.title).join(', ') || 'None'}
Reputation: ${playerData.reputation?.map((r: any) => `${r.factionName}: ${r.reputation}`).join('; ') || 'None'}

Recent Dialogue History:
${recentHistory.slice(-5).map(h => `${h.role}: ${h.content}`).join('\n')}

Based on all this context, generate appropriate dialogue and action options. The NPC's response should reflect their personality and current relationship with the player. Options should be contextually relevant and adapt to the game state.`

  const messages = [
    { role: 'assistant', content: SYSTEM_PROMPT },
    { role: 'user', content: contextPrompt }
  ]

  const completion = await zai.chat.completions.create({
    messages,
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    }
    throw new Error('No JSON found in response')
  } catch (error) {
    console.error('Failed to parse NPC dialogue options:', error)
    return null
  }
}

export async function POST(req: NextRequest) {
  try {
    const { sessionId, npcName } = await req.json()

    if (!sessionId || !npcName) {
      return NextResponse.json(
        { success: false, error: 'Session ID and NPC name are required' },
        { status: 400 }
      )
    }

    const session = await db.gameSession.findUnique({
      where: { id: sessionId },
      include: {
        playerState: true,
        inventory: true,
        quests: true,
        relationships: true,
        reputation: true,
        characters: true,
        dialogues: {
          orderBy: { turnNumber: 'desc' },
          take: 20
        }
      }
    })

    if (!session) {
      return NextResponse.json(
        { success: false, error: 'Session not found' },
        { status: 404 }
      )
    }

    const npcData = session.characters.find(c => c.name === npcName)
    if (!npcData) {
      return NextResponse.json(
        { success: false, error: 'NPC not found' },
        { status: 404 }
      )
    }

    const relationship = session.relationships.find(r => r.npcName === npcName)

    const playerData = {
      health: session.playerState.health,
      maxHealth: session.playerState.maxHealth,
      gold: session.playerState.gold,
      level: session.playerState.level,
      location: session.playerState.location,
      timeOfDay: session.playerState.timeOfDay,
      inventory: session.inventory,
      quests: session.quests,
      reputation: session.reputation
    }

    const recentHistory = session.dialogues.map(d => ({ role: d.role, content: d.content }))

    const result = await generateNPCDialogueOptions(
      npcName,
      sessionId,
      npcData,
      playerData,
      recentHistory
    )

    if (!result) {
      return NextResponse.json(
        { success: false, error: 'Failed to generate dialogue options' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      npcName,
      npcRole: npcData.role,
      npcDescription: npcData.description,
      npcPersonality: npcData.personality,
      npcMemory: npcData.memory,
      npcKnowledge: npcData.knowledge,
      relationship: {
        affinity: relationship?.affinity || 50,
        status: relationship?.status || 'neutral',
        interactionCount: relationship?.interactionCount || 0
      },
      ...result
    })
  } catch (error) {
    console.error('NPC dialogue options error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
