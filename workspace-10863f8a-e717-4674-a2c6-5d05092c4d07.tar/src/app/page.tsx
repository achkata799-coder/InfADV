'use client'

import React, { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Loader2, Mic, MicOff, Volume2, VolumeX, RefreshCw, Book, Users, Package, Map, Heart, Coins, Clock, Save, Play, ArrowLeft, Dumbbell, Eye, MessageSquare, Sword, X, MessageCircle, Zap } from 'lucide-react'

interface GameState {
  playerName?: string
  health: number
  maxHealth: number
  gold: number
  level: number
  experience: number
  location?: string
  timeOfDay: string
}

interface InventoryItem {
  itemName: string
  description?: string
  quantity: number
  rarity: string
  itemType: string
}

interface Quest {
  title: string
  description: string
  status: string
  priority: string
}

interface Relationship {
  id: string
  npcName: string
  npcRole?: string
  affinity: number
  status: string
  interactionCount: number
}

interface Reputation {
  factionName: string
  factionType?: string
  reputation: number
  description?: string
}

interface DialogueMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
  image?: string
  audio?: string
}

interface GameSettings {
  setting: string
  genre: string
  plotEssentials: string
  mediaType: string
}

interface SavedGame {
  sessionId: string
  gameState: GameState
  dialogues: DialogueMessage[]
  inventory: InventoryItem[]
  quests: Quest[]
  relationships: Relationship[]
  reputation: Reputation[]
  savedAt: string
}

interface NPCDialogueOption {
  id: string
  type: string
  text: string
  description: string
  requirements: {
    minAffinity: number
    maxAffinity: number
    requiredItems: string[]
    requiredQuests: string[]
    blockedIf: string[]
  }
}

interface NPCDialogueData {
  npcName: string
  npcRole?: string
  npcDescription: string
  relationship: {
    affinity: number
    status: string
    interactionCount: number
  }
  npcResponse: string
  dialogueOptions: NPCDialogueOption[]
  actionOptions: NPCDialogueOption[]
}

type Screen = 'menu' | 'new-game' | 'game'

type ActionButtonType = 'do' | 'say' | 'see' | 'story'

// FormattedText component to parse and display markdown-style formatting
const FormattedText: React.FC<{ text: string }> = ({ text }) => {
  // Parse the formatted text and convert to HTML
  const parseFormattedText = (input: string): React.ReactNode[] => {
    const lines = input.split('\n')
    const result: React.ReactNode[] = []

    lines.forEach((line, lineIndex) => {
      if (line.trim() === '') {
        // Empty line - create a paragraph break
        if (result.length > 0) {
          result.push(<br key={`br-${lineIndex}`} />)
        }
        return
      }

      // Parse the line for formatting
      let remainingText = line
      const parts: React.ReactNode[] = []
      let position = 0

      while (position < remainingText.length) {
        // Check for bold text with dialogue: **"text"**
        const dialogueMatch = remainingText.slice(position).match(/\*\*"([^"]+)"\*\*/)
        if (dialogueMatch && dialogueMatch.index === 0) {
          parts.push(
            <strong key={`dialogue-${lineIndex}-${position}`}>
              "{dialogueMatch[1]}"
            </strong>
          )
          position += dialogueMatch[0].length
          continue
        }

        // Check for bold text: **text**
        const boldMatch = remainingText.slice(position).match(/\*\*([^*]+)\*\*/)
        if (boldMatch && boldMatch.index === 0) {
          parts.push(
            <strong key={`bold-${lineIndex}-${position}`}>
              {boldMatch[1]}
            </strong>
          )
          position += boldMatch[0].length
          continue
        }

        // Check for italic text: *text*
        const italicMatch = remainingText.slice(position).match(/\*([^*]+)\*/)
        if (italicMatch && italicMatch.index === 0) {
          parts.push(
            <em key={`italic-${lineIndex}-${position}`}>
              {italicMatch[1]}
            </em>
          )
          position += italicMatch[0].length
          continue
        }

        // Regular text
        const nextBold = remainingText.slice(position).indexOf('**')
        const nextItalic = remainingText.slice(position).indexOf('*')
        
        let regularTextEnd = remainingText.length
        if (nextBold !== -1 && nextBold < regularTextEnd) regularTextEnd = nextBold
        if (nextItalic !== -1 && nextItalic < regularTextEnd) regularTextEnd = nextItalic

        if (position < regularTextEnd) {
          parts.push(remainingText.slice(position, regularTextEnd))
          position = regularTextEnd
        } else {
          position++
        }
      }

      // Add the parsed line
      result.push(
        <span key={`line-${lineIndex}`} className="inline">
          {parts}
        </span>
      )

      // Add line break if not the last line
      if (lineIndex < lines.length - 1) {
        result.push(<br key={`lb-${lineIndex}`} />)
      }
    })

    return result
  }

  return <div className="whitespace-pre-wrap leading-relaxed">{parseFormattedText(text)}</div>
}

export default function AdventureGame() {
  const [screen, setScreen] = useState<Screen>('menu')
  const [sessionId, setSessionId] = useState<string>('')
  const [gameState, setGameState] = useState<GameState>({
    health: 100,
    maxHealth: 100,
    gold: 0,
    level: 1,
    experience: 0,
    timeOfDay: 'day'
  })
  const [dialogues, setDialogues] = useState<DialogueMessage[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [quests, setQuests] = useState<Quest[]>([])
  const [relationships, setRelationships] = useState<Relationship[]>([])
  const [reputation, setReputation] = useState<Reputation[]>([])
  const [inputText, setInputText] = useState('')
  const [isRecording, setIsRecording] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isGeneratingImage, setIsGeneratingImage] = useState(false)
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false)
  const [activeTab, setActiveTab] = useState<'inventory' | 'quests' | 'relationships' | 'reputation'>('inventory')
  
  const [gameSettings, setGameSettings] = useState<GameSettings>({
    setting: '',
    genre: '',
    plotEssentials: '',
    mediaType: 'Game'
  })
  
  const [savedGames, setSavedGames] = useState<SavedGame[]>([])
  const [saveName, setSaveName] = useState('')

  // NPC Interaction State
  const [npcDialogOpen, setNpcDialogOpen] = useState(false)
  const [selectedNPC, setSelectedNPC] = useState<string>('')
  const [npcDialogueData, setNpcDialogueData] = useState<NPCDialogueData | null>(null)
  const [isFetchingNPCDialogue, setIsFetchingNPCDialogue] = useState(false)

  const scrollRef = useRef<HTMLDivElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  useEffect(() => {
    loadSavedGames()
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [dialogues])

  const scrollToBottom = () => {
    setTimeout(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight
      }
    }, 50)
  }

  const loadSavedGames = () => {
    try {
      const saved = localStorage.getItem('adventure_saves')
      if (saved) {
        setSavedGames(JSON.parse(saved))
      }
    } catch (error) {
      console.error('Failed to load saved games:', error)
    }
  }

  const saveGame = (name: string) => {
    try {
      const savedGame: SavedGame = {
        sessionId,
        gameState,
        dialogues,
        inventory,
        quests,
        relationships,
        reputation,
        savedAt: new Date().toISOString()
      }
      
      const existingIndex = savedGames.findIndex(g => g.sessionId === sessionId)
      const updated = existingIndex >= 0 
        ? [...savedGames.slice(0, existingIndex), savedGame, ...savedGames.slice(existingIndex + 1)]
        : [...savedGames, savedGame]
      
      setSavedGames(updated)
      localStorage.setItem('adventure_saves', JSON.stringify(updated))
      return true
    } catch (error) {
      console.error('Failed to save game:', error)
      return false
    }
  }

  const loadGame = (savedGame: SavedGame) => {
    setSessionId(savedGame.sessionId)
    setGameState(savedGame.gameState)
    setDialogues(savedGame.dialogues)
    setInventory(savedGame.inventory)
    setQuests(savedGame.quests)
    setRelationships(savedGame.relationships)
    setReputation(savedGame.reputation)
    setScreen('game')
    scrollToBottom()
  }

  const deleteSave = (sessionIdToDelete: string) => {
    const updated = savedGames.filter(g => g.sessionId !== sessionIdToDelete)
    setSavedGames(updated)
    localStorage.setItem('adventure_saves', JSON.stringify(updated))
  }

  const startNewGame = async () => {
    setIsProcessing(true)
    try {
      const response = await fetch('/api/adventure/init', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(gameSettings)
      })
      const data = await response.json()
      if (data.success) {
        setSessionId(data.sessionId)
        setGameState(data.gameState)
        setDialogues(data.dialogues || [])
        setInventory(data.inventory || [])
        setQuests(data.quests || [])
        setRelationships(data.relationships || [])
        setReputation(data.reputation || [])

        if (data.dialogues && data.dialogues.length > 0) {
          const lastDialogue = data.dialogues[data.dialogues.length - 1]
          if (lastDialogue.role === 'assistant') {
            await generateSceneImage(lastDialogue.content)
          }
        }
        
        setScreen('game')
        scrollToBottom()
      }
    } catch (error) {
      console.error('Failed to start new game:', error)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleAction = async (actionType: ActionButtonType, actionText: string = '') => {
    if (!sessionId) return

    const actionPayload = actionText.trim() || ''
    setInputText('')
    setIsProcessing(true)

    try {
      const response = await fetch('/api/adventure/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          sessionId, 
          action: actionPayload,
          actionType: actionType
        })
      })
      const data = await response.json()

      if (data.success) {
        const newDialogues = [
          ...dialogues,
          { role: 'user' as const, content: actionPayload },
          { role: 'assistant' as const, content: data.response }
        ]
        setDialogues(newDialogues)
        setGameState(data.gameState)
        setInventory(data.inventory)
        setQuests(data.quests)
        setRelationships(data.relationships)
        setReputation(data.reputation)

        if (data.response) {
          await generateSceneImage(data.response)
          await generateSpeechAudio(data.response)
        }
        
        scrollToBottom()
      }
    } catch (error) {
      console.error('Failed to send action:', error)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleWait = async () => {
    if (!sessionId) return
    await handleAction('wait', 'Wait')
  }

  const generateSceneImage = async (description: string) => {
    setIsGeneratingImage(true)
    try {
      const response = await fetch('/api/adventure/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, description })
      })
      const data = await response.json()
      if (data.success && data.image) {
        setDialogues(prev => {
          const updated = [...prev]
          const lastIdx = updated.length - 1
          if (lastIdx >= 0 && updated[lastIdx].role === 'assistant') {
            updated[lastIdx].image = data.image
          }
          return updated
        })
      }
    } catch (error) {
      console.error('Failed to generate image:', error)
    } finally {
      setIsGeneratingImage(false)
    }
  }

  const generateSpeechAudio = async (text: string) => {
    setIsGeneratingAudio(true)
    try {
      const response = await fetch('/api/adventure/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voice: 'tongtong', speed: 1.0 })
      })
      const data = await response.json()
      if (data.success && data.audio) {
        setDialogues(prev => {
          const updated = [...prev]
          const lastIdx = updated.length - 1
          if (lastIdx >= 0 && updated[lastIdx].role === 'assistant') {
            updated[lastIdx].audio = data.audio
          }
          return updated
        })
      }
    } catch (error) {
      console.error('Failed to generate speech:', error)
    } finally {
      setIsGeneratingAudio(false)
    }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' })
        const audioFile = new File([audioBlob], 'recording.wav', { type: 'audio/wav' })

        setIsProcessing(true)
        try {
          const formData = new FormData()
          formData.append('audio', audioFile)
          formData.append('sessionId', sessionId!)

          const response = await fetch('/api/adventure/transcribe', {
            method: 'POST',
            body: formData
          })
          const data = await response.json()

          if (data.success && data.text) {
            setInputText(data.text)
          }
        } catch (error) {
          console.error('Failed to transcribe audio:', error)
        } finally {
          setIsProcessing(false)
        }
      }

      mediaRecorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error('Failed to start recording:', error)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const playAudio = (audioData: string) => {
    setIsSpeaking(true)
    const audio = new Audio('data:audio/wav;base64,' + audioData)
    audio.onended = () => setIsSpeaking(false)
    audio.play()
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      if (inputText.trim()) {
        handleAction('do', inputText)
      }
    }
  }

  const resetGame = () => {
    setSessionId('')
    setDialogues([])
    setGameState({ health: 100, maxHealth: 100, gold: 0, level: 1, experience: 0, timeOfDay: 'day' })
    setInventory([])
    setQuests([])
    setRelationships([])
    setReputation([])
    setScreen('menu')
  }

  const openNPCDialog = async (npcName: string) => {
    if (!sessionId) return

    setSelectedNPC(npcName)
    setIsFetchingNPCDialogue(true)
    setNpcDialogOpen(true)
    setNpcDialogueData(null)

    try {
      const response = await fetch('/api/adventure/npc-dialogue-options', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, npcName })
      })
      const data = await response.json()

      if (data.success) {
        setNpcDialogueData(data)
      }
    } catch (error) {
      console.error('Failed to fetch NPC dialogue options:', error)
    } finally {
      setIsFetchingNPCDialogue(false)
    }
  }

  const handleNPCOptionSelect = (optionText: string) => {
    setInputText(optionText)
    setNpcDialogOpen(false)
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return 'bg-amber-500'
      case 'epic': return 'bg-purple-500'
      case 'rare': return 'bg-blue-500'
      default: return 'bg-gray-500'
    }
  }

  const getRelationshipBadgeColor = (status: string) => {
    switch (status) {
      case 'hostile': return 'bg-red-500'
      case 'neutral': return 'bg-gray-500'
      case 'friendly': return 'bg-green-500'
      case 'ally': return 'bg-blue-600'
      default: return 'bg-gray-500'
    }
  }

  const lastAssistantDialogue = dialogues.filter(d => d.role === 'assistant').pop()

  if (screen === 'menu') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Card className="w-full max-w-2xl bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-6">
            <div className="flex justify-center mb-4">
              <Book className="w-16 h-16 text-primary" />
            </div>
            <CardTitle className="text-3xl bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Infinite AI Adventure
            </CardTitle>
            <p className="text-muted-foreground mt-2">
              An immersive, AI-powered choose-your-own-adventure experience
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => setScreen('new-game')}
              className="w-full h-14 text-lg"
              size="lg"
            >
              <Play className="w-5 h-5 mr-2" />
              Start New Adventure
            </Button>
            
            <Button
              onClick={() => setScreen('game')}
              disabled={savedGames.length === 0}
              variant="outline"
              className="w-full h-14 text-lg"
              size="lg"
            >
              <Save className="w-5 h-5 mr-2" />
              Load Adventure {savedGames.length > 0 && '(' + savedGames.length + ')'}
            </Button>

            {savedGames.length > 0 && (
              <div className="pt-4 border-t">
                <h3 className="font-semibold mb-3">Saved Games</h3>
                <ScrollArea className="h-64">
                  <div className="space-y-2 pr-4">
                    {savedGames.map((game, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg bg-muted/50 hover:bg-muted/80 transition-colors flex items-center justify-between group"
                      >
                        <div className="flex-1">
                          <div className="font-medium">
                            {game.gameState.location || 'Adventure'} - Level {game.gameState.level}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(game.savedAt).toLocaleString()}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => loadGame(game)}
                          >
                            Load
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteSave(game.sessionId)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            ×
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            <div className="pt-4 border-t">
              <h3 className="font-semibold mb-3 text-sm text-muted-foreground">
                Your progress is automatically saved to browser storage
              </h3>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (screen === 'new-game') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
        <Card className="w-full max-w-xl bg-white/95 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setScreen('menu')}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <CardTitle>Create New Adventure</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Setting / World</label>
              <Input
                value={gameSettings.setting}
                onChange={(e) => setGameSettings({ ...gameSettings, setting: e.target.value })}
                placeholder="e.g., Medieval Fantasy Kingdom, Cyberpunk City, Wild West Town..."
                className="h-11"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Genre / Theme</label>
              <Input
                value={gameSettings.genre}
                onChange={(e) => setGameSettings({ ...gameSettings, genre: e.target.value })}
                placeholder="e.g., High Fantasy, Sci-Fi, Horror, Mystery, Western..."
                className="h-11"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Plot Essentials</label>
              <Textarea
                value={gameSettings.plotEssentials}
                onChange={(e) => setGameSettings({ ...gameSettings, plotEssentials: e.target.value })}
                placeholder="Describe key elements you want in your story (e.g., ancient prophecy, lost treasure, political intrigue, magical curse...)"
                rows={3}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Media Type / Style</label>
              <Input
                value={gameSettings.mediaType}
                onChange={(e) => setGameSettings({ ...gameSettings, mediaType: e.target.value })}
                placeholder="e.g., Game, TV Show, Movie, Book, Tabletop RPG..."
                className="h-11"
              />
            </div>

            <div className="pt-4 flex gap-3">
              <Button
                onClick={() => setScreen('menu')}
                variant="outline"
                className="flex-1 h-11"
                disabled={isProcessing}
              >
                Back
              </Button>
              <Button
                onClick={startNewGame}
                className="flex-1 h-11"
                disabled={isProcessing || (!gameSettings.setting && !gameSettings.genre)}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating World...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Begin Adventure
                  </>
                )}
              </Button>
            </div>

            {!gameSettings.setting && !gameSettings.genre && (
              <p className="text-sm text-muted-foreground text-center">
                Please provide at least a Setting or Genre to begin
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  const ActionButton: React.FC<{ type: ActionButtonType; icon: React.ReactNode; label: string; onClick: () => void }> = ({ type, icon, label, onClick }) => {
    return (
      <Button
        variant={isProcessing ? 'outline' : 'secondary'}
        size="sm"
        onClick={onClick}
        disabled={isProcessing}
        className="flex flex-col items-center gap-1"
        title={label}
      >
        {React.cloneElement(icon, { className: 'w-4 h-4' })}
        <span className="text-xs">{label}</span>
      </Button>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setScreen('menu')}
              title="Main Menu"
            >
              <Book className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                Infinite AI Adventure
              </h1>
              <p className="text-xs text-muted-foreground">
                {gameState.location || 'Exploring...'} - {gameState.timeOfDay}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500" />
              <span className="font-semibold text-lg">{gameState.health}/{gameState.maxHealth}</span>
            </div>
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-500" />
              <span className="font-semibold text-lg">{gameState.gold}</span>
            </div>
            <Badge variant="outline" className="text-sm">
              Level {gameState.level}
            </Badge>
            <Input
              value={saveName}
              onChange={(e) => setSaveName(e.target.value)}
              placeholder="Save name..."
              className="w-40 h-9"
              disabled={isProcessing}
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                if (saveName.trim()) {
                  const success = saveGame(saveName.trim())
                  if (success) {
                    setSaveName('')
                  }
                }
              }}
              title="Save Game"
              disabled={!saveName.trim() || isProcessing}
            >
              <Save className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={resetGame} title="New Game">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 gap-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 flex flex-col gap-4">
            <Card className="flex-1 flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Map className="w-5 h-5" />
                  Story
                  {(isGeneratingImage || isGeneratingAudio) && (
                    <span className="text-xs text-muted-foreground ml-2">
                      Generating {isGeneratingImage ? 'scene' : ''}{isGeneratingImage && isGeneratingAudio ? ' & ' : ''}{isGeneratingAudio ? 'speech' : ''}...
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1">
                <ScrollArea className="h-[550px] pr-4" ref={scrollRef}>
                  <div className="space-y-6">
                    {dialogues.map((dialogue, idx) => (
                      <div
                        key={idx}
                        className={'flex ' + (dialogue.role === 'user' ? 'justify-end' : 'justify-start')}
                      >
                        <div
                          className={'max-w-[85%] rounded-lg p-4 ' + 
                            (dialogue.role === 'user'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted')
                          }
                        >
                          {dialogue.role === 'assistant' ? (
                            <FormattedText text={dialogue.content} />
                          ) : (
                            <p className="whitespace-pre-wrap leading-relaxed">{dialogue.content}</p>
                          )}
                          {dialogue.image && (
                            <img
                              src={'data:image/png;base64,' + dialogue.image}
                              alt="Scene"
                              className="mt-3 rounded-lg w-full max-h-64 object-cover"
                            />
                          )}
                        </div>
                      </div>
                    ))}
                    {isProcessing && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>AI is thinking...</span>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
              <CardContent className="border-t pt-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 mb-3">
                    <Button
                      variant={isRecording ? 'destructive' : 'outline'}
                      size="icon"
                      onClick={isRecording ? stopRecording : startRecording}
                      disabled={isProcessing}
                      title={isRecording ? 'Stop recording' : 'Start voice input'}
                    >
                      {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>
                    
                    <Input
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Describe your action or choice..."
                      disabled={isProcessing}
                      className="flex-1"
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        if (inputText.trim()) {
                          handleAction('do', inputText)
                        }
                      }}
                      disabled={!inputText.trim() || isProcessing}
                    >
                      {isProcessing ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        'Send'
                      )}
                    </Button>
                    
                    <Button
                      onClick={handleWait}
                      disabled={isProcessing}
                      variant="secondary"
                      className="flex-1"
                      title="Wait - advance time and observe"
                    >
                      <Clock className="w-4 h-4 mr-2" />
                      Wait
                    </Button>

                    {lastAssistantDialogue && lastAssistantDialogue.audio && (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => lastAssistantDialogue.audio && playAudio(lastAssistantDialogue.audio)}
                        disabled={isSpeaking}
                        title="Play voice narration"
                      >
                        {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </Button>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3">
                    <ActionButton
                      type="say"
                      icon={<MessageSquare />}
                      label="Say"
                      onClick={() => handleAction('say')}
                    />
                    <ActionButton
                      type="see"
                      icon={<Eye />}
                      label="See"
                      onClick={() => handleAction('see')}
                    />
                    <ActionButton
                      type="story"
                      icon={<Dumbbell />}
                      label="Story"
                      onClick={() => handleAction('story')}
                    />
                    <ActionButton
                      type="do"
                      icon={<Sword />}
                      label="Do"
                      onClick={() => inputText.trim() && handleAction('do', inputText)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col gap-4">
            <Card className="flex-1">
              <CardHeader>
                <div className="flex gap-2">
                  <Button
                    variant={activeTab === 'inventory' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab('inventory')}
                    className="flex-1"
                  >
                    <Package className="w-4 h-4 mr-2" />
                    Inventory
                  </Button>
                  <Button
                    variant={activeTab === 'quests' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab('quests')}
                    className="flex-1"
                  >
                    <Book className="w-4 h-4 mr-2" />
                    Quests
                  </Button>
                  <Button
                    variant={activeTab === 'relationships' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab('relationships')}
                    className="flex-1"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    NPCs
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <ScrollArea className="h-[450px]">
                  {activeTab === 'inventory' && (
                    <div className="space-y-3">
                      {inventory.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-8">
                          Your inventory is empty
                        </p>
                      ) : (
                        inventory.map((item, idx) => (
                          <div key={idx} className="p-3 rounded-lg bg-muted/50">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold">{item.itemName}</span>
                                  <Badge className={'text-xs ' + getRarityColor(item.rarity)}>
                                    {item.rarity}
                                  </Badge>
                                </div>
                                {item.description && (
                                  <p className="text-xs text-muted-foreground mt-1">
                                    {item.description}
                                  </p>
                                )}
                              </div>
                              <Badge variant="secondary" className="text-xs">
                                {item.quantity}
                              </Badge>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {activeTab === 'quests' && (
                    <div className="space-y-3">
                      {quests.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-8">
                          No active quests
                        </p>
                      ) : (
                        quests.filter(q => q.status === 'active').map((quest, idx) => (
                          <div key={idx} className="p-3 rounded-lg bg-muted/50">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold">{quest.title}</span>
                                  <Badge
                                    variant={quest.priority === 'high' ? 'destructive' : 'secondary'}
                                    className="text-xs"
                                  >
                                    {quest.priority}
                                  </Badge>
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {quest.description}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {activeTab === 'relationships' && (
                    <div className="space-y-3">
                      {relationships.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-8">
                          No relationships yet
                        </p>
                      ) : (
                        relationships.map((rel, idx) => {
                          const statusColor = getRelationshipBadgeColor(rel.status)
                          return (
                            <div
                              key={idx}
                              className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                              onClick={() => openNPCDialog(rel.npcName)}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <span className="font-semibold">{rel.npcName}</span>
                                    {rel.npcRole && (
                                      <Badge variant="outline" className="text-xs">
                                        {rel.npcRole}
                                      </Badge>
                                    )}
                                    <MessageCircle className="w-3 h-3 text-muted-foreground" />
                                  </div>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Badge
                                      variant="outline"
                                      className={'text-xs ' + statusColor}
                                    >
                                      {rel.status}
                                    </Badge>
                                    <span className="text-xs text-muted-foreground">
                                      {rel.interactionCount} interactions
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="text-2xl font-bold text-primary">
                                  {rel.affinity}
                                </div>
                                <div className="w-16 h-1.5 bg-muted rounded-full mt-1">
                                  <div
                                    className="h-full bg-primary rounded-full transition-all"
                                    style={{ width: Math.min(rel.affinity, 100) + '%' }}
                                  />
                                </div>
                              </div>
                            </div>
                          )
                        })
                      )}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>

            {reputation.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Reputation</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-28">
                    <div className="space-y-2">
                      {reputation.map((rep, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                          <div className="flex-1">
                            <div className="text-sm font-medium">{rep.factionName}</div>
                            {rep.factionType && (
                              <div className="text-xs text-muted-foreground">
                                {rep.factionType}
                              </div>
                            )}
                          </div>
                          <Badge
                            variant={rep.reputation > 0 ? 'default' : 'destructive'}
                            className="text-xs"
                          >
                            {rep.reputation > 0 ? '+' : ''}{rep.reputation}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* NPC Interaction Modal */}
      {npcDialogOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-lg shadow-lg max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="border-b p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-primary" />
                <div>
                  <h2 className="text-xl font-bold">{npcDialogueData?.npcName || selectedNPC}</h2>
                  {npcDialogueData?.npcRole && (
                    <p className="text-sm text-muted-foreground">{npcDialogueData.npcRole}</p>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setNpcDialogOpen(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Content */}
            <ScrollArea className="flex-1 p-4">
              {isFetchingNPCDialogue ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                  <span className="ml-2 text-muted-foreground">Loading dialogue options...</span>
                </div>
              ) : npcDialogueData ? (
                <div className="space-y-6">
                  {/* NPC Response */}
                  <div className="p-4 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-2">
                      <MessageCircle className="w-4 h-4 text-primary" />
                      <span className="text-sm font-semibold text-muted-foreground">
                        {npcDialogueData.npcName} says:
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed">{npcDialogueData.npcResponse}</p>
                  </div>

                  {/* Relationship Info */}
                  <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Relationship: {npcDialogueData.relationship.status}</p>
                        <p className="text-xs text-muted-foreground">
                          {npcDialogueData.relationship.interactionCount} interactions
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">
                          {npcDialogueData.relationship.affinity}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Dialogue Options */}
                  {npcDialogueData.dialogueOptions.length > 0 && (
                    <div>
                      <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                        <MessageCircle className="w-4 h-4" />
                        Dialogue Options
                      </h3>
                      <div className="space-y-2">
                        {npcDialogueData.dialogueOptions.map((option) => (
                          <button
                            key={option.id}
                            onClick={() => handleNPCOptionSelect(option.text)}
                            className="w-full text-left p-3 rounded-lg border border-border hover:bg-accent hover:border-accent transition-all"
                          >
                            <p className="text-sm font-medium">{option.text}</p>
                            <p className="text-xs text-muted-foreground mt-1">{option.description}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Action Options */}
                  {npcDialogueData.actionOptions.length > 0 && (
                    <div>
                      <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        Action Options
                      </h3>
                      <div className="space-y-2">
                        {npcDialogueData.actionOptions.map((option) => (
                          <button
                            key={option.id}
                            onClick={() => handleNPCOptionSelect(option.text)}
                            className="w-full text-left p-3 rounded-lg border border-border hover:bg-accent hover:border-accent transition-all"
                          >
                            <p className="text-sm font-medium">{option.text}</p>
                            <p className="text-xs text-muted-foreground mt-1">{option.description}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Failed to load dialogue options
                </p>
              )}
            </ScrollArea>

            {/* Footer */}
            <div className="border-t p-4 bg-muted/30">
              <p className="text-xs text-muted-foreground text-center">
                Select an option to populate the text input. You can edit it before sending.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
